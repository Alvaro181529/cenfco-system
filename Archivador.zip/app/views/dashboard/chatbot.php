<?php require 'template/head.php' ?>
<?php require 'template/navbar.php' ?>
<main id="main" class="container">
    Chatbot
</main>
<?php require 'template/foot.php' ?>
