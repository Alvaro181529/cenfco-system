<?php require 'template/head.php' ?>
<?php require 'template/navbar.php' ?>
<main id="inicio" class="container">
    Blogs
</main>
<?php require 'template/foot.php' ?>
