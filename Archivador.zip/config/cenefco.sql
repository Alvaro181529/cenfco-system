-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 29-03-2025 a las 22:47:16
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cenefco`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `certificados`
--

CREATE TABLE `certificados` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `precioIndividual` int(11) NOT NULL,
  `precioCurso` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `fechaEmision` date NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `certificados`
--

INSERT INTO `certificados` (`id`, `titulo`, `precioIndividual`, `precioCurso`, `descripcion`, `fechaEmision`, `create_at`) VALUES
(3, 'jasdskdn', 6, 7, 'aslkdnjksdbasj', '2024-02-02', '2025-03-17 16:50:03'),
(4, 'askdaskjdn', 0, 3, 'askdjaskdn', '2025-03-06', '2025-03-17 16:50:03'),
(5, 'asdnaskjn', 0, 3, '', '2025-03-06', '2025-03-17 16:50:03'),
(6, 'sadjsdnA ajskas', 3, 8, 'adhasdnhj', '2025-03-06', '2025-03-17 16:50:03'),
(7, 'Nuevo corso cenfco', 0, 3, 'h¿no se que poner', '2025-03-06', '2025-03-17 16:50:03'),
(8, 'jwqbdqeb', 0, 3, 'ASDB', '2025-03-06', '2025-03-17 16:50:03'),
(9, 'nuevo curso', 0, 4, 'prueba de duracion de cursos de fechas', '2025-03-12', '2025-03-17 16:50:03'),
(10, 'Nuevo Curso', 0, 3, 'Esta es la descripcion', '2025-03-19', '2025-03-19 20:33:11'),
(11, 'Nuevo Curso', 0, 89, 'askdmaskmdakmdaskdm', '2025-03-23', '2025-03-23 19:37:12'),
(12, 'Nuevo Curso', 0, 89, 'KSAMDASJDN', '2025-03-23', '2025-03-23 19:46:34'),
(13, 'Nuevo Curso', 0, 89, 'KSAMDASJDN', '2025-03-23', '2025-03-23 19:47:39'),
(14, 'Nuevo Curso', 0, 89, 'KSAMDASJDN', '2025-03-23', '2025-03-23 19:47:46'),
(15, 'Nuevo Curso', 0, 89, 'KSAMDASJDN', '2025-03-23', '2025-03-23 19:47:55'),
(16, 'sadmsdn', 0, 89, 'ksamdasdmaksdm', '2025-03-23', '2025-03-23 19:48:34'),
(17, 'asjdnaskn', 0, 2, 'asndkjas', '2025-03-24', '2025-03-24 01:59:29'),
(18, 'sdajaskdnaskjn', 0, 532, 'asdjkdnaskjdn', '2025-03-26', '2025-03-26 13:13:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `docente` varchar(100) DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `descripcion` longtext NOT NULL,
  `precio` varchar(11) NOT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `grupoFacebook` varchar(100) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mostrarInicio` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`id`, `titulo`, `docente`, `categoria`, `descripcion`, `precio`, `fechaInicio`, `fechaFin`, `imagen`, `grupoFacebook`, `create_at`, `mostrarInicio`) VALUES
(23, 'Nuevo corso cenfco 22', 'sadnasd JHSAJDBASJD', 'Ciencias Humanas', 'h¿no se que poner', '3', NULL, NULL, 'Nuevo corso cenfco 2267c99638575d5.jpg', NULL, '2025-03-17 16:51:09', 0),
(24, 'Nuevo corso cenfco 2029', 'sadnasd JHSAJDBASJD', 'Ciencias Humanas', 'h¿no se que poner', '3', NULL, NULL, 'Nuevo corso cenfco 202567c99142f30a7.png', NULL, '2025-03-17 16:51:09', 0),
(26, 'jwqbdqeb', '2 3', 'Ciencias Humanas', 'ASDB', '3', NULL, NULL, 'jwqbdqeb67ca27f647ce6.png', NULL, '2025-03-17 16:51:09', 0),
(27, 'askdmaksjdn', 'kasjdkajn', 'Ciencias Humanas', 'aksjdn asjdasn', '8', NULL, NULL, 'askdmaksjdn67cfc05142ca4.png', NULL, '2025-03-17 16:51:09', 0),
(28, 'nuevo curso', 'dsjndaskjn jsdkasndk', 'Ciencias Humanas', 'prueba de duracion de cursos de fechas', '4', '2024-02-10', '2024-04-10', 'nuevo curso67d0dfb576371.png', NULL, '2025-03-17 16:51:09', 0),
(29, 'Nuevo Curso', 'dasnhikdn bhsjabd', 'Ciencias Humanas', 'Esta es la descripcion', '3', '2025-03-12', '2025-03-29', 'Nuevo Curso67db2a076f9b0.jpg', NULL, '2025-03-19 20:33:11', 0),
(30, 'Nuevo Curso', 'JDSAKDANSD', 'Ciencias Humanas', 'KSAMDASJDN', '89', '2024-03-24', '2024-04-24', 'Nuevo Curso67e0656b26105.png', NULL, '2025-03-23 19:47:55', 0),
(31, 'sadmsdn', 'jasdnakjdn', 'Ciencias Humanas', 'ksamdasdmaksdm', '89', '2025-04-24', '2027-02-22', 'sadmsdn67e06592859c1.png', NULL, '2025-03-23 19:48:34', 1),
(32, 'asjdnaskn', 'dasnhikdn bhsjabd', 'Tecnologias', 'asndkjas', '2', '2025-03-03', '2025-03-19', 'asjdnaskn67e0bc8114796.png', NULL, '2025-03-24 01:59:29', 1),
(33, 'sdajaskdnaskjn', 'adshdb jshdabds', 'Ciencias Humanas', 'asdjkdnaskjdn', '532', '2025-03-04', '2025-03-26', 'sdajaskdnaskjn67e3fd6103b0c.jpg', NULL, '2025-03-26 13:13:05', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docentes`
--

CREATE TABLE `docentes` (
  `id` int(11) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `firma` varchar(100) DEFAULT NULL,
  `curriculum` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) NOT NULL,
  `estadoCivil` varchar(100) NOT NULL,
  `direccionDomicilio` varchar(100) DEFAULT NULL,
  `universidad` varchar(100) NOT NULL,
  `observacion` text NOT NULL,
  `carnet` varchar(15) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `docentes`
--

INSERT INTO `docentes` (`id`, `nombres`, `apellidos`, `correo`, `foto`, `firma`, `curriculum`, `telefono`, `estadoCivil`, `direccionDomicilio`, `universidad`, `observacion`, `carnet`, `create_at`) VALUES
(1, '2', '3', '', '', '', '', '', '', '', '', '', '24234', '2025-03-17 16:51:33'),
(2, 'dsjndaskjn', 'jsdkasndk', '', '', '', '', '', '', '', '', '', '6736172361723', '2025-03-17 16:51:33'),
(3, 'sadnasd', 'JHSAJDBASJD', 'JDhsajdhb', 'jashbdjasb', '', '', 'jashbdjasbd', 'jsabhdasj', 'sjahdbsajdb', 'jashdbasjhbd', '', 'asjjhasdb', '2025-03-17 16:51:33'),
(4, 'dasnhikdn', 'bhsjabd', 'dbahsahjb@djnas.cin', NULL, '', '', 'dashdbjasb', 'Soltero', NULL, 'shajsgvadh', 'asgbjdashda', '237y8327', '2025-03-17 16:51:33'),
(5, 'adjaksdn', 'jasndj', 'jasdkasn@ddfd.von', NULL, '', '', 'asjdna', 'Soltero', 'adnaskjd', 'axkjasdn', 'sajdkdn', '73287', '2025-03-17 16:51:33'),
(6, 'adshdb', 'jshdabds', 'jdhsad@gmail.com', NULL, '', '', 'asdgasd', 'Casado', 'ashdgashdv', 'ashgdashdv', 'hsagvdghavsdgahsvd', 'jhsabd', '2025-03-17 16:51:33'),
(7, 'asdas', 'asnh dasj', 'asjdh@gmail.com', 'asdas67c92dda4b11f.png', '', '', 'qnsdjasn', 'Soltero', 'ajsnd', 'jasdnasjk', 'asdasdasd', 'asjn', '2025-03-17 16:51:33'),
(8, 'sajdk', 'ndsakdn', 'kdjsandkn@gmkdsadm', 'sajdkndsakdn67c92e33584eb.png', '', '', 'asjdnaksdn', 'Soltero', 'dkjsansd', 'askdnasjk', 'asdhasndj', 'jsadndkjsan', '2025-03-17 16:51:33'),
(9, 'sabhdashbd', 'ashbdjasb', 'ahdbasj@gmail.com', 'Foto_sabhdashbd_ashbdjasb67cf7552c8a6e.png', 'Firma_sabhdashbd_ashbdjasb67cf7552c8bc9.png', 'Curriculum_sabhdashbd_ashbdjasb67cf7552c8cde.pdf', '32643762', 'Soltero', 'hasbdjasbdhasbj', 'ashdbahsdv', 'hasdbasjhas sadbhjahd', 'ashbdjas', '2025-03-17 16:51:33'),
(12, 'Nuevo ', 'Usuario', 'jdhsa@gmail.com', 'Foto_8773844lp_Nuevo _Usuario.png', 'Firma_8773844lp_Nuevo _Usuario.png', 'Curriculum_8773844lp_Nuevo _Usuario.pdf', '37276323764', 'Casado', 'ashdasjdbasj', 'sajdnjashdbashdb', 'Esta seria una bosevacion del Docente', '8773844lp', '2025-03-17 16:51:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `id` int(11) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `carnet` varchar(50) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `direccionDomicilio` varchar(50) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`id`, `nombres`, `apellidos`, `carnet`, `foto`, `telefono`, `correo`, `direccionDomicilio`, `create_at`) VALUES
(1, 'adnasd', 'jashdbaj', 'sadhbasdj', '2', 'asdbasjhdb', 'sahdbasjhb', 'asdnkajsdn', '2025-03-17 16:52:23'),
(2, 'asdnaskjn', 'sajdnskdn', 'dasjndkasnd', NULL, 'kjsandkasn', 'jsanddkas@gmail.com', 'sadjdnkajd', '2025-03-17 16:52:23'),
(3, 'actualizado', 'kdjsankjd', 'kjdnsakdn', NULL, 'kdjaskjdn', 'kdjansdkj@gmail.com', 'kjdnskn', '2025-03-17 16:52:23'),
(4, 'asdskdn', 'WHQDBJ', 'JHADBSDJ', NULL, 'aDSJKANSBD', 'kjdaskn@nasdjn', 'JDASJHBDJAS', '2025-03-17 16:52:23'),
(5, 'asJDANHN', 'JNSDJKAN', 'JKASNDJKASN', NULL, 'N', 'KASJDNKJ@gmail.com', 'SJADKSN', '2025-03-17 16:52:23'),
(6, 'salkdmaskdn', 'kjasdkn', 'ddjasnd', NULL, 'danajd', 'askjdn@gmail.com', 'jwndasjdbasjhdb', '2025-03-17 16:52:23'),
(8, 'Nuevo usuario', 'sadnjasd', '3827382', NULL, '37287', 'alvaro@gmailc.osn', 'asndasdn', '2025-03-17 16:52:23'),
(10, 'Nuevo ', 'Usuario Para', '9199698lp', 'Foto_9199698lp_Nuevo _Usuario Para.png', '7263762', 'nuevo@gmail.com', 'skjabdajhbdjadbh', '2025-03-17 16:52:23'),
(11, 'Alvaro Herbert', 'Medrano Perez', '9199698 LP', NULL, '75281378', 'alvaro@gmail.com', 'av Buenos aires', '2025-03-17 16:52:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `id` int(11) NOT NULL DEFAULT 0,
  `titulo` varchar(100) NOT NULL,
  `docente` varchar(100) DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `descripcion` longtext NOT NULL,
  `precio` varchar(11) NOT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `grupoFacebook` varchar(100) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mostrarInicio` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id`, `titulo`, `docente`, `categoria`, `descripcion`, `precio`, `fechaInicio`, `fechaFin`, `imagen`, `grupoFacebook`, `create_at`, `mostrarInicio`) VALUES
(23, 'Nuevo corso cenfco 22', 'sadnasd JHSAJDBASJD', 'Ciencias Humanas', 'h¿no se que poner', '3', NULL, NULL, 'Nuevo corso cenfco 2267c99638575d5.jpg', NULL, '2025-03-17 16:51:09', 0),
(24, 'Nuevo corso cenfco 2029', 'sadnasd JHSAJDBASJD', 'Ciencias Humanas', 'h¿no se que poner', '3', NULL, NULL, 'Nuevo corso cenfco 202567c99142f30a7.png', NULL, '2025-03-17 16:51:09', 0),
(26, 'jwqbdqeb', '2 3', 'Ciencias Humanas', 'ASDB', '3', NULL, NULL, 'jwqbdqeb67ca27f647ce6.png', NULL, '2025-03-17 16:51:09', 0),
(27, 'askdmaksjdn', 'kasjdkajn', 'Ciencias Humanas', 'aksjdn asjdasn', '8', NULL, NULL, 'askdmaksjdn67cfc05142ca4.png', NULL, '2025-03-17 16:51:09', 0),
(28, 'nuevo curso', 'dsjndaskjn jsdkasndk', 'Ciencias Humanas', 'prueba de duracion de cursos de fechas', '4', '2024-02-10', '2024-04-10', 'nuevo curso67d0dfb576371.png', NULL, '2025-03-17 16:51:09', 0),
(29, 'Nuevo Curso', 'dasnhikdn bhsjabd', 'Ciencias Humanas', 'Esta es la descripcion', '3', '2025-03-12', '2025-03-29', 'Nuevo Curso67db2a076f9b0.jpg', NULL, '2025-03-19 20:33:11', 0),
(30, 'Nuevo Curso', 'JDSAKDANSD', 'Ciencias Humanas', 'KSAMDASJDN', '89', '2024-03-24', '2024-04-24', 'Nuevo Curso67e0656b26105.png', NULL, '2025-03-23 19:47:55', 0),
(31, 'sadmsdn', 'jasdnakjdn', 'Ciencias Humanas', 'ksamdasdmaksdm', '89', '2025-04-24', '2027-02-22', 'sadmsdn67e06592859c1.png', NULL, '2025-03-23 19:48:34', 1),
(32, 'asjdnaskn', 'dasnhikdn bhsjabd', 'Tecnologias', 'asndkjas', '2', '2025-03-03', '2025-03-19', 'asjdnaskn67e0bc8114796.png', NULL, '2025-03-24 01:59:29', 1),
(33, 'sdajaskdnaskjn', 'adshdb jshdabds', 'Ciencias Humanas', 'asdjkdnaskjdn', '532', '2025-03-04', '2025-03-26', 'sdajaskdnaskjn67e3fd6103b0c.jpg', NULL, '2025-03-26 13:13:05', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `cantidad` int(100) NOT NULL,
  `fechaAdquisicion` date NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id`, `nombre`, `descripcion`, `cantidad`, `fechaAdquisicion`, `create_at`) VALUES
(5, 'wqeqwe kasmlkasdm', 'sadasd', 3, '2025-03-27', '2025-03-17 16:52:42'),
(6, 'asdjkd', 'sadnkjdnaskjd', 8, '2025-03-05', '2025-03-17 16:52:42'),
(7, 'asdjkd', 'sadnkjdnaskjd', 8, '2025-03-05', '2025-03-17 16:52:42'),
(8, 'sadnksjdn', 'sadasa', 7, '2024-02-05', '2025-03-17 16:52:42'),
(9, 'asd nasjdn', 'asjdkdn', 9, '2025-02-05', '2025-03-17 16:52:42'),
(10, 'asdnaskjdn', 'wqdmaksnd', 7, '2024-02-05', '2025-03-17 16:52:42'),
(11, 'asdnaskjdn', 'wqdmaksnd', 7, '2024-02-05', '2025-03-17 16:52:42'),
(12, 'adsakjdn', 'kjsndjadnajsdb', 7, '2024-02-05', '2025-03-17 16:52:42'),
(13, 'adsakjdn', 'kjsndjadnajsdb', 7, '2024-02-05', '2025-03-17 16:52:42'),
(14, 'asdnaskjdn', 'asndjasknbd', 9, '2024-02-05', '2025-03-17 16:52:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `role` varchar(50) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `correo`, `role`, `created_at`) VALUES
(6, 'alvaroq', '$2y$10$9nDgSreT22pOdNz1dWxpoeGCsVLijjEkTml/GFZHxxEL1HswJCL4O', 'alva1@gmail.com', 'user', '2025-03-05 22:01:43'),
(7, 'alvaro1', '$2y$10$sfiH.pu2Q009n82CFlADuO25isfLqBU8qej4fU02NN1thosbvyfEO', 'alvaq1@gmail.com', 'user', '2025-03-05 22:14:56'),
(8, 'juan', '$2y$10$KT3Fg1YOCOUBbmxysjBHE.cLS.C2qxYpqk5lIZemoD15Bd1ytTJLm', 'juan@gmail.com', 'user', '2025-03-05 22:20:50'),
(9, 'Alvaro Medrnao', '$2y$10$QlyO6FvgJe2thp1SI1F/xeksH285Y1VBEuX5i725wQR.VQEaIjdVy', 'aljak@123.com', 'user', '2025-03-07 01:18:38'),
(10, 'unico', '$2y$10$gQS/qm5ZX2SeKqQoCDXbB.uKTNG.WrhqxbjtyB0wFhH/q9saerf0W', 'unico@gmai.com', 'user', '2025-03-07 01:28:32'),
(12, 'asdf', '$2y$10$seuu2I/w73TjWVmmJ/PauOWOWZd6XiVAiHPoE5rvfdTnsSmHaYnrC', 'asdf@gmail.com', 'user', '2025-03-07 01:37:36'),
(14, 'un', '$2y$10$rfuKF5kSGfu57pWOfyteYO0grOHENVJI/YCcL/10zLo.0qVXADc4.', 'un@gmail.com', 'user', '2025-03-07 01:50:38'),
(15, 'Adminsitrador', '$2y$12$CD0QKfgr5fTzMqUlkNtP/O9tzTbFRJXD8uGwudNxUeVDdULIc4QMO', 'administrador@gmail.com', 'Administrador', '2025-03-08 01:12:59'),
(25, 'Administrador', '$2y$12$BfsaRB8pnTJetOpZTHZzROkY5VMHY5r5WePCJMQgU0hBpqUnV4ywC', 'admin@gmail.com', 'Administrador', '2025-03-10 22:45:33'),
(26, 'Ventas', '1234Qwer', 'ventas@gmail.com', 'Vendedor', '2025-03-26 12:31:15'),
(27, 'ventas@gmail.com', '1234qwer', 'ventas1@gmail.com', 'Vendedor', '2025-03-26 12:32:58'),
(28, 'vendedor', '$2y$12$hkCkA7aUL4B5O4jrrk5aie0rqeEK4942XvWBsdmqiwFENw856c.86', 'venta@gmail.com', 'Vendedor', '2025-03-26 12:33:52'),
(29, 'vendedor', '$2y$12$DVZsSA.2CLMXMN0THRC/..YgCoaKQtZvvu/EnppTJEUcBIx7j23b6', 'vendedor@gmail.com', 'Vendedor', '2025-03-26 12:41:03');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `id_curso` int(11) DEFAULT NULL,
  `id_certificado` int(11) DEFAULT NULL,
  `id_estudiante` int(11) DEFAULT NULL,
  `comprobante` varchar(255) DEFAULT NULL,
  `externoNombre` varchar(100) DEFAULT NULL,
  `externoCarnet` varchar(100) DEFAULT NULL,
  `precio` decimal(11,0) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `createt_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `id_curso`, `id_certificado`, `id_estudiante`, `comprobante`, `externoNombre`, `externoCarnet`, `precio`, `descripcion`, `tipo`, `user`, `createt_at`) VALUES
(1, 27, NULL, 11, NULL, 'Alvaro Herbert Medrano Perez', '9199698 LP', 39, 'asdnasjkdnaskjdnaskj asdjnaskjd', 'curso', 'Adminsitrador', '2025-03-16 01:42:43'),
(4, 24, NULL, 11, NULL, '', '', 3, 'ADNASJDB', 'cursos', '', '2025-03-16 00:05:21'),
(5, 24, NULL, 4, NULL, 'asdskdn WHQDBJ', 'JHADBSDJ', 3, 'ASJDKSDNJHB ', 'curso', 'Adminsitrador', '2025-03-16 00:15:07'),
(6, 23, NULL, 4, NULL, '', '', 3, 'Sn', 'undefined', 'Adminsitrador', '2025-03-16 00:12:48'),
(7, 23, NULL, 11, NULL, '', '', 3, '', 'undefined', 'Adminsitrador', '2025-03-16 00:12:02'),
(11, 0, NULL, 0, NULL, 'samdklmd', 'sakmldmaslmd', 73283, 'asdasdas', 'certificado', 'Adminsitrador', '2025-03-17 23:12:42'),
(17, NULL, 4, 1, NULL, 'adnasd jashdbaj', 'sadhbasdj', 4, '0', 'certificado', 'Adminsitrador', '2025-03-14 04:46:10'),
(18, NULL, 4, 1, NULL, 'adnasd jashdbaj', 'sadhbasdj', 33, '0', 'certificado', 'Adminsitrador', '2025-03-14 04:47:06'),
(19, NULL, 4, 1, NULL, 'adnasd jashdbaj', 'sadhbasdj', 3, 'q', 'certificado', 'Adminsitrador', '2025-03-14 04:48:16'),
(23, NULL, NULL, NULL, NULL, 'samkldmaslkdm', 'lkmasldmasl', 787, NULL, 'asjdnkajsdn', 'jasdaskd', '2025-03-14 04:51:47'),
(24, NULL, 5, 2, NULL, 'asdnaskjn sajdnskdn', 'dasjndkasnd', 0, 'asdaspdk', 'certificado', 'Adminsitrador', '2025-03-15 18:22:25'),
(25, NULL, 6, 11, NULL, 'Alvaro Herbert Medrano Perez', '9199698 LP', 3, 'sl,adlsakmd', 'certificado', 'Adminsitrador', '2025-03-15 18:23:09'),
(26, NULL, 7, 2, NULL, 'asdnaskjn sajdnskdn', 'dasjndkasnd', 3, 'dmasjkd', 'certificado', 'Adminsitrador', '2025-03-15 23:13:02'),
(28, 23, NULL, 3, NULL, 'actualizado kdjsankjd', 'kjdnsakdn', 3, 'asndkjasdn', 'curso', 'Adminsitrador', '2025-03-16 00:24:06'),
(31, 24, NULL, 3, NULL, 'actualizado kdjsankjd', 'kjdnsakdn', 3, 'as', 'curso', 'Adminsitrador', '2025-03-16 00:44:22'),
(33, 26, NULL, NULL, NULL, 'adsnajdn', 'asjdnaskn', 8, NULL, 'curso', 'asdnasjdb', '2025-03-16 00:48:28'),
(37, 24, NULL, 11, NULL, 'Alvaro Herbert Medrano Perez', '9199698 LP', 3, 'asmdkasldm', 'curso', 'Adminsitrador', '2025-03-16 01:01:55'),
(42, 23, NULL, 0, NULL, 'ASDASD', 'ADASDAS', 3, 'SADASDAS', 'CURSO', 'Adminsitrador', '2025-03-16 01:40:19'),
(47, 24, NULL, 0, NULL, 'asd', 'asdas', 3, 'sakmdalsdm', 'curso', 'Adminsitrador', '2025-03-16 01:42:24'),
(48, 24, NULL, 0, NULL, 'asdnasjkdn', 'sadnajksn', 3, 'kjasdn', 'curso', 'Adminsitrador', '2025-03-16 01:47:40'),
(49, 24, NULL, 0, NULL, 'adad', 'ansdna', 3, 'asjd', 'curso', 'Adminsitrador', '2025-03-16 01:50:25'),
(50, 24, NULL, 0, NULL, 'SADASD', 'ASDAS', 3, 'SADS', 'curso', 'Adminsitrador', '2025-03-16 01:51:21'),
(51, 0, NULL, 1, NULL, 'adnasd jashdbaj', 'sadhbasdj', 3, 'sdjakn', 'curso', 'Adminsitrador', '2025-03-17 23:03:57'),
(52, 0, NULL, 2, NULL, 'asdnaskjn sajdnskdn', 'dasjndkasnd', 4, 'asdmasldm', 'certificado', 'Adminsitrador', '2025-03-17 23:04:26'),
(53, 24, NULL, 11, NULL, 'Alvaro Herbert Medrano Perez', '9199698 LP', 3, 'njdsakdnkjasnd', 'curso', 'Adminsitrador', '2025-03-19 01:23:28');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `certificados`
--
ALTER TABLE `certificados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `docentes`
--
ALTER TABLE `docentes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_curso` (`id_curso`),
  ADD KEY `fk_certificado` (`id_certificado`),
  ADD KEY `fk_estudiante` (`id_estudiante`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `certificados`
--
ALTER TABLE `certificados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `docentes`
--
ALTER TABLE `docentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_certificado` FOREIGN KEY (`id_certificado`) REFERENCES `certificados` (`id`),
  ADD CONSTRAINT `fk_curso` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`),
  ADD CONSTRAINT `fk_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
